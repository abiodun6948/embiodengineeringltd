<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="favicon.jpg" />

	
	<title>SAYONE SOLUTION</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
<!--

Template 2075 Digital Team

http://www.tooplate.com/view/2075-digital-team

-->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/et-line-font.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
	<style>
	    .float {
            position: fixed;
            width: 42px;
            height: 42px;
            bottom: 40px;
            right: 25px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 3px 7px #272424;
            z-index: 100;
        	        
	    }
         .insta{
        	position:fixed;
        	width:42px;
        	height:42px;
        	bottom:95px;
        	right:25px;
        	background-color:#25d366;
        	color:#FFF;
        	border-radius:50px;
        	text-align:center;
            font-size:30px;
        	box-shadow: 2px 3px 7px #272424;
            z-index:100;
            background: #f09433; 
            background: -moz-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); 
            background: -webkit-linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
            background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f09433', endColorstr='#bc1888',GradientType=1 );
        }
	</style>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
 <style>
.testimonial{
    padding-top: 70px;
    margin: 50px 15px 0;
    border: 1px solid #fff;
    text-align: center;
    position: relative;
    transition: all 0.7s ease 0s;
}
.testimonial:hover{ border-color: #e7e3e3; }
.testimonial .pic{
    width: 95px;
    height: 95px;
    border-radius: 50%;
    background: #fff;
    padding: 7px;
    position:absolute;
    top: -50px;
    left: 50%;
    overflow: hidden;
    transform: translateX(-50%);
    transition: all 0.7s ease 0s;
}
.testimonial:hover .pic{ background: #1d3033; }
.testimonial .pic img{
    width: 100%;
    height: auto;
    border-radius: 50%;
}
.testimonial .title{
    font-size: 16px;
    font-weight: 700;
    color: #eabd44;
    text-transform: uppercase;
    margin: 0 0 10px 0;
}
.testimonial .description{
    font-size: 15px;
    color: #999;
    line-height: 25px;
    border-bottom: 1px solid #f7f7f7;
    padding: 0 25px 35px;
    margin: 0;
}
.testimonial .testimonial-content{
    padding: 15px 25px 12px;
    border: 1px solid #f7f7f7;
    border-top: none;
    position: relative;
    text-align: left;
    transition: all 500ms ease 0s;
}
.testimonial:hover .testimonial-content{ border-color: #1d3033; }
.testimonial .testimonial-content:after{
    content: "";
    width: 100%;
    height: 0;
    background: #1d3033;
    position: absolute;
    bottom: 0;
    left: 0;
    z-index: -1;
    transition: all 0.7s ease 0s;
}
.testimonial:hover .testimonial-content:after{ height: 100%; }
.testimonial-content .testimonial-profile{ display: inline-block; }
.testimonial .name{
    font-size: 16px;
    font-weight: 700;
    color: #3d3d3d;
    text-transform: uppercase;
    margin: 0 0 3px;
    transition: all 700ms ease 0s;
}
.testimonial:hover .name{ color: #fff; }
.testimonial .post{
    font-size: 14px;
    color: #eabd44;
    text-transform: capitalize;
}
.testimonial .rating{
    display: inline-block;
    padding: 1px 5px;
    margin: 0;
    list-style: none;
    background: #eabd44;
    position: absolute;
    right: 25px;
}
.testimonial .rating li{
    display: inline-block;
    font-size: 14px;
    color: #fff;
}
.owl-theme .owl-controls{
    width: 100%;
    position: absolute;
    top: 50%;
}
.owl-theme .owl-controls .owl-buttons div{
    width: 45px;
    height: 40px;
    line-height: 37px;
    border-radius: 3px;
    background: #fff;
    border: 1px solid #ececec;
    padding: 0;
    opacity: 1;
    transition: all 0.4s ease-in-out 0s;
}
.owl-theme .owl-controls .owl-buttons div:hover{
    background: #eabd44;
    border-color: #eabd44;
}
.owl-prev,
.owl-next{
    display:none;
    position: absolute;
    left: -3%;
}
.owl-next{
    display:none;
    left: auto;
    right: -3%;
}
.owl-prev:before,
.owl-next:before{
    display:none;
    content: "\f104";
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    font-size: 25px;
    color: #ececec;
}
.owl-next:before{ content: "\f105"; }
@media only screen and (max-width: 990px){
    .owl-theme .owl-controls,
    .owl-prev,
    .owl-next{
        display:none;
        position: relative;
        left: 0;
        right: 0;
    }
}
@media only screen and (max-width: 768px){
    .testimonial .testimonial-content{
        padding: 15px 10px 12px;
    }
    .testimonial .rating{
        right: 12px;
    }
}
</style>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<a href="https://www.instagram.com/say1developer/" class="insta" target="_blank">
<i class="fa fa-instagram my-float"></i>
</a>
<a href="https://api.whatsapp.com/send?phone=+918460203320&amp;text=Hello,%20SayOne%20Solution" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<!-- preloader section -->
<div class="preloader">
	<img src="images/loader.gif">
</div>

<!-- navigation section -->
<section class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">Sayone Solution</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#home" class="smoothScroll">HOME</a></li>
				<li><a href="#work" class="smoothScroll">SERVICES</a></li>
				<li><a href="#product" class="smoothScroll">PRODUCT</a></li>
				<li><a href="#portfolio" class="smoothScroll">PORTFOLIO</a></li>
				<li><a href="#team" class="smoothScroll">ONLINE SUPPORT</a></li>
				<li><a href="#about" class="smoothScroll">ABOUT</a></li>
				<li><a href="#contact" class="smoothScroll">CONTACT</a></li>
			</ul>
		</div>
	</div>
</section>

<!-- home section -->
<section id="home">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<img style="width:50%;" src="images/bglogo.png">
				
				<h1>SAYONE SOLUTION</h1>
				<hr>
				<h3>WEB | DIGITAL-AUTOMATION | IOT PLATFORM</h3>
			</div>
		</div>
	</div>		
</section>

<!-- work section -->
<section id="work">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="section-title">
					<h1 class="heading bold">SERVICES</h1>
					<hr>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
				<i class="fa fa-globe medium-icon"></i>
					<h3>WEB</h3>
					<hr>
					<p>Web identity is the primary requirement for all emerging business.We build an awesome website as per the customer requirement with extra features based on Iot devices(Eg: Live status of the shop/office-open or close).The world of technology is dynamic in nature. We develop sustainable technological solutions.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
				<i class="fa fa-cogs  medium-icon"></i>
					<h3>AUTOMATION</h3>
					<hr>
					<p>With the rapid growth in lifestyle and technology. Sometimes it's difficult to manage and operate our day to day objects like water pump, washing machines, etc. Now it's easy to integrate it with a smartphone and automatically manage it. We are here to deliver a custom solution to such problems.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="1s">
				<i class="fa fa-wifi  medium-icon"></i>
					<h3>IOT</h3>
					<hr>
					<p>Management plays an important role In this era of technology, We are here to provide you an IoT platform where you can easily integrate and manage IoT devices- Eg managing water station for timely refilling it, Automatic garden watering system, automating a routine task, etc.</p>
			</div>
			
		</div>
	</div>
</section>

<section id="product">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<h1 class="heading bold">PRODUCT</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<img  src="images/itsondesk.png" class="img-responsive" alt="about img">
			</div>
			<div class="col-md-6 col-sm-12">
				<h3 class="bold">ITSONDESK - IOT PORTAL</h3>
				<h2 class="heading bold">Feel the simplicity..Feel the Smartness..</h2>
				<!-- Nav tabs -->
    			
    			<p>Itsondesk is an online platform for managing and interlinking the Iot devices. It allows users to perform analytics on every Iot devices. 
                It is best platform for the web developers, it allows developers to easily create an API for the Iot devices and hence easily integrate on website
                or any other application. It is best platfrom for delivering the custom automation solution to our clients and customers.</p>
                
                <h3><p>Who is Itsondesk For?</p></h3>
                <p>Itsondesk is right for you if:</p>
                <ul>
                    <li>You want a secured and simplified application for Iot.</li>
                    <li>You want a simple but robust platfrom for Iot.</li>
                    <li>You need broad compatibility with different devices and API's.</li>
                    <li>You want a platform that requires less coding and configuration.</li>
                    <li>You are not interested in complex and costly platform like Amazone,Microsoft Azure.</li>
                    <li>You want to deliver a custom Iot solution to your customer.</li>
                    
                </ul>
                <a href=""></a>            

				<!-- tab panes -->
				
			</div>
		</div>
	</div>
</section>
<!-- about section -->

<!-- portfolio section -->
<section id="portfolio">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="section-title">
					<h1 class="heading bold">OUR PORTFOLIO</h1>
					<hr>
				</div>
				<!-- ISO section -->
				<div class="iso-section">
					<ul class="filter-wrapper clearfix">
                   		 <li><a href="#" data-filter="*" class="selected opc-main-bg">All</a></li>
                   		 <li><a href="#" class="opc-main-bg" data-filter=".web">WEB DEVELOPMENT</a></li>
                   		 <li><a href="#" class="opc-main-bg" data-filter=".sms">SMS PORTAL</a></li>
                    	 <li><a href="#" class="opc-main-bg" data-filter=".iot">IOT</a></li>
               		</ul>
               		<div class="iso-box-section wow fadeIn" data-wow-delay="0.9s">
               			<div class="iso-box-wrapper col4-iso-box">

               				 
               				 <div class="iso-box sms col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/sms1.jpg" data-lightbox-gallery="portfolio-gallery"><img title="SMS portal" src="images/sms1.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box sms col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/sms2.JPG" data-lightbox-gallery="portfolio-gallery"><img title="SMS Portal UI" src="images/sms2.JPG" alt="portfolio img"></a>
               				 </div>

               				 <div class="iso-box web mobile col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/web1.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Creative Web Designing" src="images/web1.jpg" alt="portfolio img"></a>
               				 </div>

               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/rfid1.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Custom RFID System" src="images/rfid1.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/prod.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondeskdevice" src="images/prod.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/sensor.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondeskdevice" src="images/sensor.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/rfid2.jpg" data-lightbox-gallery="portfolio-gallery"><img title="RFID Attendance UI" src="images/rfid2.jpg" alt="portfolio img"></a>
               				 </div>

               				 <div class="iso-box web photoshop col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/web2.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Device Compatibility Website" src="images/web2.jpg" alt="portfolio img"></a>
               				 </div>
               				 
                             <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot2.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Custom IOT Application" src="images/iot2.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot1.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Custom Smart Home Application" src="images/iot1.jpg" alt="portfolio img"></a>
               				 </div>
               				 
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot4.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Water Status Indicator" src="images/iot4.jpg" alt="portfolio img"></a>
               				 </div>
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot5.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondesk IOT Portal" src="images/iot5.jpg" alt="portfolio img"></a>
               				 </div>
                            <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot6.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondesk IOT Portal" src="images/iot6.jpg" alt="portfolio img"></a>
               				 </div>
               				 <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/iot7.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondesk IOT Portal" src="images/iot7.jpg" alt="portfolio img"></a>
               				 </div>
                            <div class="iso-box iot col-lg-4 col-md-4 col-sm-6">
               				 	<a href="images/prod_final.jpg" data-lightbox-gallery="portfolio-gallery"><img title="Itsondesk IOT Portal" src="images/prod_final.jpg" alt="portfolio img"></a>
               				 </div>

               			</div>
               		</div>

				</div>
			</div>
		</div>
	</div>
</section>		
<section id="client">
    <div id="tf-team" class="text-center">
        <div class="overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
        				<div class="section-title">
        					<h1 class="heading bold">Client testimonials</h1>
        					<hr>
        				</div>
        			</div>
        <div class="col-md-12">
            <div id="testimonial-slider" class="owl-carousel">
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/client/us1.jpg" alt="">
                    </div>
                    <h3 class="title">Michael Jaweed,USA</h3>
                    <p class="description">Excellent product delivery. Sayonesolution went above and beyond.Great working with Sayonesolution. Helped me in many different programming languages.</p>
                    <div class="testimonial-content">
                        <div class="testimonial-profile">
                            <h3 class="name">Senior Developer</h3>
                            <span class="post">Orlando, United States</span>
                        </div>
                        <ul class="rating">
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                        </ul>
                    </div>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/client/client3.jpg" alt="">
                    </div>
                    <h3 class="title">Carl M,Australia</h3>
                    <p class="description">Good communication and work, understood requirements very well. Will definetly hire again.</p>
                    <div class="testimonial-content">
                        <div class="testimonial-profile">
                            <h3 class="name">Senior Developer</h3>
                            <span class="post">Gosnells, Australia</span>
                        </div>
                        <ul class="rating">
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                        </ul>
                    </div>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/client/mal.jpg" alt="">
                    </div>
                    <h3 class="title">Mohd Haizul,Malaysia</h3>
                    <p class="description">Very talented... Have very good knowledge.. Highly recommended.. Good communication skill. Will hire again.</p>
                    <div class="testimonial-content">
                        <div class="testimonial-profile">
                            <h3 class="name">Business Analyst</h3>
                            <span class="post">Kluang, Malaysia</span>
                        </div>
                        <ul class="rating">
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                        </ul>
                    </div>
                </div>
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/client/mal2.jpg" alt="">
                    </div>
                    <h3 class="title">Bossa T,Malaysia</h3>
                    <p class="description">He is an expert programmer, who delivers his project timely.Will hire again.</p>
                    <div class="testimonial-content">
                        <div class="testimonial-profile">
                            <h3 class="name">Developer</h3>
                            <span class="post">Skudai, Malaysia</span>
                        </div>
                        <ul class="rating">
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                            <li class="fa fa-star"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
    </section>
<!-- team section -->
<section id="team">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="section-title">
					<h1 class="heading bold">ONLINE SUPPORT</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-9">
				<form action="model.php" method="get" class="wow fadeInUp" data-wow-delay="0.6s">
					<div class="col-md-6 col-sm-6 col-md-offset-5">
						<input type="text" class="form-control" placeholder="Enter model Number" name="model_no" data-wow-delay="0.3s"></br>
						<button class="smoothScroll btn btn-success" data-wow-delay="0.6s">Get Support</button>
					</div>
					
				</FORM>
			</div>
			
		</div>
	</div>
</section>

<section id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<h1 class="heading bold">WHO WE ARE?</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<img  src="images/About.jpg" class="img-responsive" alt="about img">
			</div>
			<div class="col-md-6 col-sm-12">
				<h3 class="bold">Sayone Solution</h3>
				<h2 class="heading bold"></h2>
				<p>We are a team of software developers. We provide different web and automation services to our customers including web development, domain services, hosting, Iot etc.</p>
				<!-- Nav tabs -->
				<div class="col-md-12 col-sm-12 col-12"> 
				    <div class="section-heading"> 
				        
				        <h4><i class="icon-target"></i> MISSION</h4> 
			        </div>
    		        <div class="text-content-big"> 
    		            <p>To create and provide standard web development,automation solutions and services with a special focus on emerging technologies.</p>
    	            </div>
    
                    <div class="section-heading">
                        <h4><i class="fa fa-eye"></i> VISION</h4> 
                    </div>
                    <div class="text-content-big"> 
                        <p>Our vision is to continue in our pursuit for excellence in offering best in class innovative solutions in diversified fields of automation and web development and business enhancements to our clients and business partners.</p>
                    </div>
                </div>
				<!-- tab panes -->
				
			</div>
		</div>
	</div>
</section>
<!-- contact section -->
<section id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="">
					<h1 class="heading bold">CONTACT US</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-2 col-sm-2 contact-info">
		    </div>
			<div class="col-md-10 col-sm-10 contact-info">
				<h2 class="heading bold">CONTACT INFO</h2>
				<p>Feel free to contact us at any time. Do share your problem with us to get best smart solution for it.</p>
				<div class="col-md-4 col-sm-4">
					<h3><i class="icon-envelope medium-icon wow bounceIn" data-wow-delay="0.6s"></i> EMAIL</h3>
					<p>sayonesolutions@gmail.com</p>
				</div>
				<div class="col-md-4 col-sm-4">
					<h3><i class="icon-phone medium-icon wow bounceIn" data-wow-delay="0.6s"></i> PHONES</h3>
					<p>+91 8668262986 | 8805556480</p>
				</div>
				<div class="col-md-4 col-sm-4">
				    <h3><i class="icon-map medium-icon wow bounceIn" data-wow-delay="0.6s"></i> ADDRESS</h3>
				<p>Yash Classic, Pashan-Pune, Maharashtra 411021.</p>
				</div>
			</div>
			<div class="col-md-2 col-sm-2 contact-info">
		    </div>
			
			
		</div>
	</div>
</section>

<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p></p>
				<hr>
				<ul class="social-icon">
				    <li><a href="https://product.sayonesolution.com"  data-wow-delay="0.6s">IOT BOX</a></li>
					<li><a href="https://www.facebook.com/sayonedeveloper/" class="fa fa-facebook wow fadeIn" data-wow-delay="0.3s"></a></li>
					<li><a href="https://www.instagram.com/say1developer" class="fa fa-instagram wow fadeIn" data-wow-delay="0.6s"></a></li>
					<li><a href="https://itsondesk.sayonesolution.com"  data-wow-delay="0.6s">IOT PLATFORM</a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>


<script src="js/jquery.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>
<script>
    var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;

    if (is_chrome) {
        var attributes = ['home', 'work', 'product', 'about', 'portfolio', 'team','contact'];
    
        $.each(attributes, function( index, value ) {
            $('a[href="#' + value + '"]').click(function() {
                $('html, body').animate({
                    scrollTop: $('#' + value).offset().top
                }, 1000);
            });
        });
    }
</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
 <script>
$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:1,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
});
</script>
</body>
</html>